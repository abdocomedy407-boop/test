import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "حول الموقع",
  description: "تعرف على موقع حاسبها: حاسبات يومية مجانية وسريعة تعمل داخل المتصفح مع حفاظ كامل على الخصوصية."
};

export default function Page() {
  return (
    <div className="container-x">
      <div className="card-x my-8">
<h1 className="text-3xl font-extrabold mb-4">حول موقع حاسبها 🧮</h1>
<p className="text-slate-500 dark:text-slate-400 mb-2"><strong>حاسبها</strong> موقع عربي مجاني يضم حاسبات يومية سريعة: خصومات، ضرائب، أرباح، أقساط، ادخار، عمر، فرق الوقت وغيرها.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">لماذا حاسبها؟</h2>
<ul className="list-disc pr-5">
<li className="text-slate-500 dark:text-slate-400 mb-1">⚡ سريع: كل الحسابات تتم داخل متصفحك فورًا دون خوادم.</li>
<li className="text-slate-500 dark:text-slate-400 mb-1">🔒 خصوصية: لا نجمع أي بيانات، والمفضلة تُحفظ محليًا على جهازك.</li>
<li className="text-slate-500 dark:text-slate-400 mb-1">📱 متجاوب: يعمل على الهاتف والكمبيوتر.</li>
<li className="text-slate-500 dark:text-slate-400 mb-1">🌙 وضع ليلي مريح للعين.</li>
<li className="text-slate-500 dark:text-slate-400 mb-1">🆓 مجاني بالكامل وبدون تسجيل.</li>
</ul>
<h2 className="text-xl font-extrabold mt-6 mb-2">تنويه</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">النتائج أدوات مساعدة دقيقة رياضيًا، وقد تختلف الأرقام الفعلية لدى البنوك والجهات حسب رسومها وسياساتها.</p>
</div>
    </div>
  );
}
