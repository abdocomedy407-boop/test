import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CALCULATORS, getCalc } from "@/lib/calculators";
import CalculatorClient from "@/components/CalculatorClient";
import AdSlot from "@/components/AdSlot";

export function generateStaticParams() {
  return CALCULATORS.map((c) => ({ slug: c.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const calc = getCalc(params.slug);
  if (!calc) return {};
  return {
    title: calc.name,
    description: calc.desc,
    alternates: { canonical: `/calculators/${calc.slug}` }
  };
}

export default function CalculatorPage({ params }: { params: { slug: string } }) {
  const calc = getCalc(params.slug);
  if (!calc) notFound();
  return (
    <div className="container-x">
      <CalculatorClient calc={calc} />
      <AdSlot name="belowCalc" label="أسفل الحاسبة" />
    </div>
  );
}
