import type { Metadata } from "next";
import { CALCULATORS } from "@/lib/calculators";
import CalcCard from "@/components/CalcCard";
import SearchBox from "@/components/SearchBox";

export const metadata: Metadata = {
  title: "جميع الحاسبات",
  description: "تصفح جميع حاسبات حاسبها المجانية: نسبة مئوية، خصم، ربح، هامش ربح، ضريبة، قسط، ادخار، عمر، فرق الوقت وتقسيم الفاتورة."
};

export default function CalculatorsPage() {
  return (
    <>
      <section className="text-center py-14 px-4">
        <h1 className="text-4xl font-extrabold mb-3">جميع <span className="text-primary">الحاسبات</span></h1>
        <p className="text-slate-500 dark:text-slate-400 text-lg mb-7">عشر حاسبات يومية سريعة ومجانية بالكامل.</p>
        <SearchBox />
      </section>
      <section className="container-x pb-14">
        <div className="grid grid-cols-[repeat(auto-fill,minmax(250px,1fr))] gap-4">
          {CALCULATORS.map((c) => <CalcCard key={c.slug} calc={c} />)}
        </div>
        <div id="noResults" className="hidden text-center text-slate-400 py-10">لا توجد نتائج مطابقة 🤔</div>
      </section>
    </>
  );
}
