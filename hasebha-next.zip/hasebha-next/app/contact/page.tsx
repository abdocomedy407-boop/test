import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "تواصل معنا",
  description: "تواصل مع فريق حاسبها لأي استفسار أو اقتراح حاسبة جديدة."
};

export default function Page() {
  return (
    <div className="container-x">
      <div className="card-x my-8">
<h1 className="text-3xl font-extrabold mb-4">تواصل معنا 📬</h1>
<p className="text-slate-500 dark:text-slate-400 mb-2">لديك سؤال أو اقتراح؟ يسعدنا سماعك! اقتراحات الحاسبات الجديدة مرحب بها دائمًا.</p>
<p className="text-slate-500 dark:text-slate-400 mb-2">راسلنا مباشرة على البريد التالي وسنرد عليك بأقرب وقت:</p>
<p className="text-slate-500 dark:text-slate-400 mb-2"><a href="mailto:contact@hasebha.com" className="text-primary font-bold">contact@hasebha.com</a></p>
</div>
    </div>
  );
}
