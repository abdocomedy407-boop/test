import type { Metadata } from "next";
import FavoritesClient from "@/components/FavoritesClient";

export const metadata: Metadata = {
  title: "المفضلة",
  description: "حاسباتك المفضلة المحفوظة محليًا في متصفحك بدون تسجيل حساب."
};

export default function FavoritesPage() {
  return (
    <>
      <section className="text-center py-14 px-4">
        <h1 className="text-4xl font-extrabold mb-3">حاسباتي <span className="text-primary">المفضلة</span> ♥</h1>
        <p className="text-slate-500 dark:text-slate-400 text-lg">حاسباتك المحفوظة تظهر هنا تلقائيًا على هذا الجهاز — بدون تسجيل.</p>
      </section>
      <section className="container-x pb-14"><FavoritesClient /></section>
    </>
  );
}
