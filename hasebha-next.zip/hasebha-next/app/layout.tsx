import type { Metadata, Viewport } from "next";
import Link from "next/link";
import "./globals.css";
import ThemeInit from "@/components/ThemeInit";
import ThemeToggle from "@/components/ThemeToggle";
import AdSlot from "@/components/AdSlot";

export const metadata: Metadata = {
  metadataBase: new URL("https://hasebha.com"),
  title: { default: "حاسبها — احسبها في ثواني", template: "%s — حاسبها" },
  description: "حاسبها — موقع حاسبات مجانية وسهلة: نسبة مئوية، خصم، ربح، هامش ربح، ضريبة، قسط، ادخار، عمر، فرق الوقت وتقسيم الفاتورة. نتائج فورية داخل متصفحك.",
  openGraph: { siteName: "حاسبها", locale: "ar_AR", type: "website" }
};
export const viewport: Viewport = { themeColor: "#0d9488" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className="min-h-screen flex flex-col">
        <ThemeInit />
        <header className="bg-white dark:bg-[#131c2e] border-b border-slate-200 dark:border-[#243349] sticky top-0 z-50 shadow-md">
          <div className="container-x flex items-center justify-between h-16 gap-3">
            <Link href="/" className="flex items-center gap-2 text-2xl font-extrabold text-primary no-underline">
              <svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="4" y="2" width="16" height="20" rx="3"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="11" x2="8" y2="11.01"/><line x1="12" y1="11" x2="12" y2="11.01"/><line x1="16" y1="11" x2="16" y2="11.01"/><line x1="8" y1="15" x2="8" y2="15.01"/><line x1="12" y1="15" x2="12" y2="18"/><line x1="16" y1="18" x2="16" y2="15.01"/></svg>
              حاسبها
            </Link>
            <nav className="hidden md:flex items-center gap-1">
              <Link className="nav-link no-underline" href="/">الرئيسية</Link>
              <Link className="nav-link no-underline" href="/calculators">الحاسبات</Link>
              <Link className="nav-link no-underline" href="/favorites">المفضلة</Link>
              <Link className="nav-link no-underline" href="/about">حول الموقع</Link>
              <Link className="nav-link no-underline" href="/contact">تواصل معنا</Link>
            </nav>
            <ThemeToggle />
          </div>
        </header>
        <AdSlot name="header" label="Header" />
        <main className="flex-1">{children}</main>
        <footer className="bg-white dark:bg-[#131c2e] border-t border-slate-200 dark:border-[#243349] mt-auto py-8">
          <div className="container-x flex flex-wrap justify-between gap-5">
            <div><h4 className="mb-2 font-bold">حاسبها</h4>
              <Link className="block text-slate-400 text-sm mb-1.5 no-underline hover:text-primary" href="/about">حول الموقع</Link>
              <Link className="block text-slate-400 text-sm mb-1.5 no-underline hover:text-primary" href="/contact">تواصل معنا</Link></div>
            <div><h4 className="mb-2 font-bold">الحاسبات</h4>
              <Link className="block text-slate-400 text-sm mb-1.5 no-underline hover:text-primary" href="/calculators">جميع الحاسبات</Link>
              <Link className="block text-slate-400 text-sm mb-1.5 no-underline hover:text-primary" href="/favorites">المفضلة</Link></div>
            <div><h4 className="mb-2 font-bold">قانوني</h4>
              <Link className="block text-slate-400 text-sm mb-1.5 no-underline hover:text-primary" href="/privacy">سياسة الخصوصية</Link>
              <Link className="block text-slate-400 text-sm mb-1.5 no-underline hover:text-primary" href="/terms">الشروط والأحكام</Link></div>
          </div>
          <div className="text-center text-slate-400 text-sm mt-6 border-t border-slate-200 dark:border-[#243349] pt-4">
            © 2026 حاسبها — احسبها في ثواني. جميع الحاسبات تعمل داخل متصفحك.
          </div>
        </footer>
      </body>
    </html>
  );
}
