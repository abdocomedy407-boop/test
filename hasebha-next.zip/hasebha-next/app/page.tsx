import { CALCULATORS } from "@/lib/calculators";
import CalcCard from "@/components/CalcCard";
import SearchBox from "@/components/SearchBox";

export default function Home() {
  return (
    <>
      <section className="text-center py-16 px-4">
        <h1 className="text-4xl md:text-5xl font-extrabold mb-3">احسبها <span className="text-primary">في ثواني</span> ⚡</h1>
        <p className="text-slate-500 dark:text-slate-400 text-lg mb-7">حاسبات مجانية وسهلة للاستخدام اليومي — بدون تسجيل، وبدون انتظار.</p>
        <SearchBox />
      </section>
      <section className="container-x pb-14">
        <h2 className="text-xl font-extrabold mb-4 mt-2">🧮 جميع الحاسبات</h2>
        <div className="grid grid-cols-[repeat(auto-fill,minmax(250px,1fr))] gap-4">
          {CALCULATORS.map((c) => <CalcCard key={c.slug} calc={c} />)}
        </div>
        <div id="noResults" className="hidden text-center text-slate-400 py-10">لا توجد نتائج مطابقة لبحثك 🤔</div>
      </section>
    </>
  );
}
