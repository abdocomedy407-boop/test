import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "سياسة الخصوصية",
  description: "سياسة خصوصية موقع حاسبها: لا نجمع بياناتك، كل الحسابات تتم داخل متصفحك، والمفضلة تُحفظ محليًا فقط."
};

export default function Page() {
  return (
    <div className="container-x">
      <div className="card-x my-8">
<h1 className="text-3xl font-extrabold mb-4">سياسة الخصوصية 🔒</h1>
<p className="text-slate-500 dark:text-slate-400 mb-2">آخر تحديث: 2026</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">1. لا نجمع بياناتك</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">جميع حاسبات الموقع تعمل بالكامل داخل متصفحك. الأرقام التي تدخلها لا تُرسل إلى أي خادم ولا تُخزن لدينا.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">2. التخزين المحلي</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">حاسباتك المفضلة وتفضيل الوضع الليلي تُحفظان في LocalStorage داخل متصفحك أنت فقط، ويمكنك حذفهما في أي وقت.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">3. ملفات تعريف الارتباط</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">عند تفعيل Google AdSense مستقبلًا، قد تستخدم Google ملفات تعريف الارتباط لعرض إعلانات مخصصة وفق سياساتها.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">4. الروابط الخارجية</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">لسنا مسؤولين عن ممارسات الخصوصية للمواقع الخارجية التي نرتبط بها.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">5. التواصل</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">لأي استفسار راسلنا على <a href="mailto:contact@hasebha.com" className="text-primary">contact@hasebha.com</a>.</p>
</div>
    </div>
  );
}
