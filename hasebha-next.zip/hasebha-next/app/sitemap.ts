import type { MetadataRoute } from "next";
import { CALCULATORS } from "@/lib/calculators";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://hasebha.com";
  const staticPages = ["", "/calculators", "/favorites", "/about", "/contact", "/privacy", "/terms"];
  return [
    ...staticPages.map((p) => ({ url: base + p, changeFrequency: "weekly" as const, priority: p === "" ? 1 : 0.8 })),
    ...CALCULATORS.map((c) => ({ url: `${base}/calculators/${c.slug}`, changeFrequency: "monthly" as const, priority: 0.9 }))
  ];
}
