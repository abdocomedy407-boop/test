import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "الشروط والأحكام",
  description: "شروط وأحكام استخدام موقع حاسبها: الخدمة مجانية للاستخدام الشخصي والنتائج لأغراض مساعدة وليست استشارة مالية."
};

export default function Page() {
  return (
    <div className="container-x">
      <div className="card-x my-8">
<h1 className="text-3xl font-extrabold mb-4">الشروط والأحكام 📜</h1>
<p className="text-slate-500 dark:text-slate-400 mb-2">آخر تحديث: 2026</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">1. قبول الشروط</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">باستخدامك الموقع فأنت توافق على هذه الشروط.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">2. طبيعة الخدمة</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">الحاسبات لأغراض مساعدة عامة، والنتائج ليست استشارة مالية أو قانونية.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">3. الملكية الفكرية</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">محتوى الموقع وتصميمه ملك لحاسبها ولا يجوز إعادة نشره تجاريًا دون إذن.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">4. حدود المسؤولية</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">ننصح بالتحقق من الأرقام المهمة لدى الجهات المختصة قبل اتخاذ قرارات مالية.</p>
<h2 className="text-xl font-extrabold mt-6 mb-2">5. التواصل</h2>
<p className="text-slate-500 dark:text-slate-400 mb-2">لأي استفسار: <a href="mailto:contact@hasebha.com" className="text-primary">contact@hasebha.com</a>.</p>
</div>
    </div>
  );
}
