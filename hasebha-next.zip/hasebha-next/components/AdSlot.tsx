"use client";
import { useEffect, useRef } from "react";
import { ADS_CONFIG, type AdSlotName } from "@/lib/ads";

export default function AdSlot({ name, label }: { name: AdSlotName; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ADS_CONFIG.enabled || !ref.current) return;
    const ins = document.createElement("ins");
    ins.className = "adsbygoogle";
    ins.style.display = "block";
    ins.setAttribute("data-ad-client", ADS_CONFIG.client);
    ins.setAttribute("data-ad-slot", ADS_CONFIG.slots[name]);
    ins.setAttribute("data-ad-format", "auto");
    ins.setAttribute("data-full-width-responsive", "true");
    ref.current.innerHTML = "";
    ref.current.appendChild(ins);
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (ADS_CONFIG.enabled) return <div className="container-x my-5" ref={ref} />;
  return <div className="container-x my-5"><div className="ad-box">مساحة إعلانية — {label}</div></div>;
}
