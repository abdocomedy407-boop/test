import Link from "next/link";
import type { Calculator } from "@/lib/calculators";
import FavButton from "./FavButton";

export default function CalcCard({ calc }: { calc: Calculator }) {
  return (
    <div className="card-x relative flex flex-col gap-2" data-search={(calc.name + " " + calc.keywords).toLowerCase()}>
      <FavButton slug={calc.slug} />
      <div className="text-4xl">{calc.icon}</div>
      <h3 className="text-lg font-extrabold"><Link href={`/calculators/${calc.slug}`}>{calc.name}</Link></h3>
      <p className="text-slate-500 dark:text-slate-400 text-sm flex-1">{calc.short}</p>
      <Link href={`/calculators/${calc.slug}`} className="btn-x text-center no-underline">استخدم الآن</Link>
    </div>
  );
}
