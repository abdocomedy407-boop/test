"use client";
import { useState } from "react";
import type { Calculator, CalcOutput } from "@/lib/calculators";
import FavButton from "./FavButton";
import CalcCard from "./CalcCard";
import { getCalc } from "@/lib/calculators";

const num = (v: string) => { const n = parseFloat(v.replace(/,/g, "")); return isFinite(n) ? n : NaN; };

export default function CalculatorClient({ calc }: { calc: Calculator }) {
  const [values, setValues] = useState<Record<string, string>>({ mode: "from" });
  const [out, setOut] = useState<CalcOutput | null>(null);
  const [err, setErr] = useState("");

  const labels: Record<string, [string, string]> = {
    from: ["النسبة %", "من رقم"], of: ["الجزء", "الكل"], change: ["القيمة القديمة", "القيمة الجديدة"]
  };

  const set = (k: string, v: string) => setValues((s) => ({ ...s, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr(""); setOut(null);
    const vals: Record<string, any> = {};
    for (const f of calc.fields) {
      const raw = values[f.key] ?? "";
      if (f.type === "select") { vals[f.key] = raw; continue; }
      if (f.type === "number") {
        const n = num(raw);
        if (!isFinite(n) && !f.optional) { setErr("يرجى ملء حقل: " + f.label); return; }
        vals[f.key] = isFinite(n) ? n : 0;
      } else {
        if (!raw && !f.optional) { setErr("يرجى ملء حقل: " + f.label); return; }
        vals[f.key] = raw;
      }
    }
    const result = calc.compute(vals);
    if (result.error) { setErr(result.error); return; }
    setOut(result);
  };

  const reset = () => { setValues({ mode: "from" }); setOut(null); setErr(""); };

  return (
    <div className="max-w-[680px] mx-auto">
      <div className="text-sm text-slate-400 pt-5">
        <a href="/" className="hover:text-primary">الرئيسية</a> / <a href="/calculators" className="hover:text-primary">الحاسبات</a> / {calc.name}
      </div>
      <div className="text-center pt-6 pb-2">
        <div className="text-5xl">{calc.icon}</div>
        <h1 className="text-3xl font-extrabold my-2">{calc.name}</h1>
        <p className="text-slate-500 dark:text-slate-400">{calc.short}</p>
      </div>

      <form onSubmit={submit} className="card-x mt-6" noValidate>
        {calc.fields.map((f) => (
          <div className="mb-4" key={f.key}>
            <label htmlFor={"f_" + f.key} className="block font-bold mb-1.5 text-sm">
              {calc.slug === "percentage" && f.key === "a" ? labels[values.mode || "from"][0]
               : calc.slug === "percentage" && f.key === "b" ? labels[values.mode || "from"][1] : f.label}
            </label>
            {f.type === "select" ? (
              <select id={"f_" + f.key} value={values[f.key] ?? "from"} onChange={(e) => set(f.key, e.target.value)} className="input-x">
                {f.options!.map((o) => <option key={o.v} value={o.v}>{o.t}</option>)}
              </select>
            ) : (
              <input id={"f_" + f.key} type={f.type} inputMode={f.type === "number" ? "decimal" : undefined}
                step="any" placeholder={f.placeholder} value={values[f.key] ?? ""}
                onChange={(e) => set(f.key, e.target.value)} className="input-x" />
            )}
          </div>
        ))}
        <div className="flex flex-wrap gap-2.5">
          <button type="submit" className="btn-x">احسب 🧮</button>
          <button type="button" onClick={reset} className="btn-outline-x">إعادة ضبط</button>
          <FavButton slug={calc.slug} label />
        </div>
        {err && <div className="mt-4 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900 rounded-xl px-4 py-3 font-semibold text-sm">{err}</div>}
        {out && (
          <div className="mt-5 bg-primary-soft dark:bg-[#134e4a] rounded-2xl p-6 text-center">
            <div className="text-slate-500 dark:text-slate-300 font-bold text-sm">{out.main.label}</div>
            <div className="text-3xl md:text-4xl font-extrabold text-primary-dark dark:text-teal-300 leading-normal">{out.main.value}</div>
            {out.subs && (
              <div className="flex flex-wrap gap-2.5 justify-center mt-4">
                {out.subs.map((s) => (
                  <div key={s.label} className="bg-white dark:bg-[#131c2e] rounded-xl px-4 py-2.5 text-sm">
                    {s.label}<b className="block text-base text-primary-dark dark:text-teal-300">{s.v}</b>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </form>

      <div className="card-x mt-6">
        <h2 className="text-lg font-extrabold mb-2">📖 كيف أستخدم هذه الحاسبة؟</h2>
        <ol className="list-decimal pr-5 text-slate-500 dark:text-slate-400">
          {calc.how.map((h, i) => <li key={i} className="mb-1">{h}</li>)}
        </ol>
      </div>

      <section className="py-10">
        <h2 className="text-xl font-extrabold mb-4">✨ حاسبات قد تهمك</h2>
        <div className="grid grid-cols-[repeat(auto-fill,minmax(250px,1fr))] gap-4">
          {calc.related.map((r) => { const c = getCalc(r); return c ? <CalcCard key={r} calc={c} /> : null; })}
        </div>
      </section>
    </div>
  );
}
