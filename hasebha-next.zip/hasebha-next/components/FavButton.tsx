"use client";
import { useEffect, useState } from "react";

const KEY = "hasebha-favorites";
const getFavs = (): string[] => { try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; } };

export default function FavButton({ slug, label }: { slug: string; label?: boolean }) {
  const [faved, setFaved] = useState(false);
  useEffect(() => { setFaved(getFavs().includes(slug)); }, [slug]);
  const toggle = () => {
    let f = getFavs();
    f = f.includes(slug) ? f.filter((x) => x !== slug) : [...f, slug];
    localStorage.setItem(KEY, JSON.stringify(f));
    setFaved(f.includes(slug));
    window.dispatchEvent(new Event("favs-changed"));
  };
  if (label)
    return (
      <button type="button" onClick={toggle} className="px-5 py-3 rounded-xl font-bold bg-primary-soft dark:bg-[#134e4a] text-primary-dark dark:text-teal-300 hover:opacity-80 transition cursor-pointer border-0">
        {faved ? "♥ في المفضلة" : "♡ أضف للمفضلة"}
      </button>
    );
  return (
    <button type="button" onClick={toggle} title="أضف للمفضلة" aria-label="أضف للمفضلة"
      className={`absolute top-3 left-3 bg-transparent border-0 text-2xl leading-none cursor-pointer transition hover:scale-125 ${faved ? "text-rose-600" : "text-slate-400"}`}>
      {faved ? "♥" : "♡"}
    </button>
  );
}
