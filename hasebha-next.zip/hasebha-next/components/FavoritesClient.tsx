"use client";
import { useEffect, useState } from "react";
import { CALCULATORS } from "@/lib/calculators";
import CalcCard from "./CalcCard";

const getFavs = (): string[] => { try { return JSON.parse(localStorage.getItem("hasebha-favorites") || "[]"); } catch { return []; } };

export default function FavoritesClient() {
  const [favs, setFavs] = useState<string[]>([]);
  useEffect(() => {
    const load = () => setFavs(getFavs());
    load();
    window.addEventListener("favs-changed", load);
    return () => window.removeEventListener("favs-changed", load);
  }, []);
  const list = CALCULATORS.filter((c) => favs.includes(c.slug));
  return (
    <>
      <div className="grid grid-cols-[repeat(auto-fill,minmax(250px,1fr))] gap-4" id="favGrid">
        {list.map((c) => <CalcCard key={c.slug} calc={c} />)}
      </div>
      {list.length === 0 && (
        <div className="text-center text-slate-400 py-10">
          <p className="text-4xl mb-2">♡</p>
          <p>لا توجد حاسبات مفضلة بعد.<br />اضغط زر القلب ♡ بجانب أي حاسبة لإضافتها هنا.</p>
          <a href="/calculators" className="btn-x inline-block mt-4 no-underline">تصفح الحاسبات</a>
        </div>
      )}
    </>
  );
}
