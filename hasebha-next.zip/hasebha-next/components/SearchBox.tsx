"use client";
import { useState } from "react";

export default function SearchBox() {
  const [q, setQ] = useState("");
  const onChange = (val: string) => {
    setQ(val);
    const query = val.trim().toLowerCase();
    let visible = 0;
    document.querySelectorAll<HTMLElement>("[data-search]").forEach((el) => {
      const hit = !query || (el.dataset.search || "").includes(query);
      el.style.display = hit ? "" : "none";
      if (hit) visible++;
    });
    const noRes = document.getElementById("noResults");
    if (noRes) noRes.style.display = visible ? "none" : "block";
  };
  return (
    <div className="relative max-w-[520px] mx-auto">
      <input type="search" value={q} onChange={(e) => onChange(e.target.value)}
        placeholder="ابحث عن حاسبة..." aria-label="ابحث عن حاسبة"
        className="w-full py-4 pr-5 pl-12 border-2 border-slate-200 dark:border-[#243349] rounded-2xl text-base bg-white dark:bg-[#131c2e] outline-none focus:border-primary" />
      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">🔍</span>
    </div>
  );
}
