"use client";
import { useEffect } from "react";

export default function ThemeInit() {
  useEffect(() => {
    const saved = localStorage.getItem("hasebha-theme");
    if (saved) document.documentElement.classList.toggle("dark", saved === "dark");
    else if (window.matchMedia("(prefers-color-scheme: dark)").matches) document.documentElement.classList.add("dark");
  }, []);
  return null;
}
