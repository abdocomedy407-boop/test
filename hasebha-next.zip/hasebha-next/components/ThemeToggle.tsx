"use client";
import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(document.documentElement.classList.contains("dark")); }, []);
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("hasebha-theme", next ? "dark" : "light");
  };
  return (
    <button onClick={toggle} title="تبديل الوضع الليلي" aria-label="تبديل الوضع الليلي"
      className="w-10 h-10 rounded-xl bg-primary-soft dark:bg-[#134e4a] text-primary-dark dark:text-teal-300 text-xl hover:opacity-80 transition cursor-pointer border-0">
      {dark ? "☀️" : "🌙"}
    </button>
  );
}
