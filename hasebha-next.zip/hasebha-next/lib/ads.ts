// ⚙️ إعدادات الإعلانات — عدّل من هنا فقط لتفعيل Google AdSense
export const ADS_CONFIG = {
  enabled: false,                       // true = تفعيل الإعلانات
  client: "ca-pub-XXXXXXXXXXXXXXXX",    // معرّف الناشر
  slots: { header: "1111111111", belowCalc: "2222222222", content: "3333333333" }
} as const;

export type AdSlotName = keyof typeof ADS_CONFIG.slots;
