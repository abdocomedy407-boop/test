export type FieldType = "number" | "date" | "datetime-local" | "select";

export interface Field {
  key: string;
  label: string;
  type: FieldType;
  placeholder?: string;
  optional?: boolean;
  options?: { v: string; t: string }[];
}

export interface CalcResult { label: string; value: string }
export interface CalcOutput { main: CalcResult; subs?: CalcResult[]; error?: string }

export interface Calculator {
  slug: string;
  name: string;
  icon: string;
  short: string;
  desc: string;
  keywords: string;
  fields: Field[];
  compute: (v: Record<string, any>) => CalcOutput;
  how: string[];
  related: string[];
}

const fmt = (n: number): string =>
  isFinite(n) ? (Math.round(n * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 }) : "—";

export const CALCULATORS: Calculator[] = [
  {
    slug: "percentage", name: "حاسبة النسبة المئوية", icon: "🧮",
    short: "احسب النسبة من رقم أو النسبة بين رقمين أو التغير المئوي.",
    desc: "حاسبة النسبة المئوية: احسب نسبة من رقم، أو النسبة التي يمثلها رقم من رقم آخر، أو التغير المئوي بين قيمتين.",
    keywords: "نسبة مئوية بالمية حساب النسبة percent",
    fields: [
      { key: "mode", label: "نوع الحساب", type: "select", options: [
        { v: "from", t: "نسبة من رقم (كم يساوي 20% من 500؟)" },
        { v: "of", t: "النسبة بين رقمين (الرقم 50 يمثل كم % من 200؟)" },
        { v: "change", t: "التغير المئوي (التغير من 80 إلى 100)" } ] },
      { key: "a", label: "القيمة الأولى", type: "number", placeholder: "مثال: 20" },
      { key: "b", label: "القيمة الثانية", type: "number", placeholder: "مثال: 500" }
    ],
    compute(v) {
      if (v.mode === "from") return { main: { label: "النتيجة", value: fmt(v.a / 100 * v.b) }, subs: [{ label: "النسبة المدخلة", value: fmt(v.a) + " %" }] };
      if (v.mode === "of") { if (v.b === 0) return { main: { label: "", value: "" }, error: "لا يمكن القسمة على صفر." };
        return { main: { label: "النتيجة", value: fmt(v.a / v.b * 100) + " %" }, subs: [{ label: "الجزء", value: fmt(v.a) }] }; }
      if (v.a === 0) return { main: { label: "", value: "" }, error: "القيمة القديمة لا يمكن أن تكون صفرًا." };
      return { main: { label: "التغير المئوي", value: fmt((v.b - v.a) / Math.abs(v.a) * 100) + " %" }, subs: [{ label: "مقدار التغير", value: fmt(v.b - v.a) }] };
    },
    how: ["اختر نوع الحساب من القائمة.", "أدخل القيمتين في الحقلين.", "اضغط زر «احسب» لعرض النتيجة فورًا."],
    related: ["discount", "profit", "tax"]
  },
  {
    slug: "discount", name: "حاسبة الخصم", icon: "🏷️",
    short: "احسب قيمة الخصم والسعر النهائي بعد الخصم.",
    desc: "حاسبة الخصم: أدخل السعر الأصلي ونسبة الخصم لتحصل على مقدار الخصم والسعر النهائي الذي ستدفعه.",
    keywords: "خصم تخفيض عروض سعر بعد خصم",
    fields: [
      { key: "price", label: "السعر الأصلي", type: "number", placeholder: "مثال: 500" },
      { key: "pct", label: "نسبة الخصم %", type: "number", placeholder: "مثال: 25" }
    ],
    compute(v) {
      if (v.pct < 0 || v.pct > 100) return { main: { label: "", value: "" }, error: "نسبة الخصم يجب أن تكون بين 0 و 100." };
      const d = v.price * v.pct / 100;
      return { main: { label: "السعر بعد الخصم", value: fmt(v.price - d) }, subs: [{ label: "مقدار الخصم", value: fmt(d) }, { label: "وفّرت", value: fmt(v.pct) + " %" }] };
    },
    how: ["أدخل السعر الأصلي للمنتج قبل الخصم.", "أدخل نسبة الخصم المئوية.", "ستظهر لك القيمة التي وفّرتها والسعر النهائي."],
    related: ["percentage", "tax", "profit"]
  },
  {
    slug: "profit", name: "حاسبة الربح", icon: "💰",
    short: "احسب مقدار الربح ونسبته من التكلفة.",
    desc: "حاسبة الربح: أدخل تكلفة الشراء وسعر البيع لتحسب مقدار الربح أو الخسارة ونسبته من التكلفة.",
    keywords: "ربح تجارة مكسب بيع شراء",
    fields: [
      { key: "cost", label: "تكلفة الشراء", type: "number", placeholder: "مثال: 300" },
      { key: "sell", label: "سعر البيع", type: "number", placeholder: "مثال: 450" }
    ],
    compute(v) {
      const p = v.sell - v.cost;
      return { main: { label: p >= 0 ? "الربح" : "الخسارة", value: fmt(Math.abs(p)) },
        subs: [ { label: "نسبة الربح من التكلفة", value: v.cost !== 0 ? fmt(p / Math.abs(v.cost) * 100) + " %" : "—" },
                { label: "هامش الربح من البيع", value: v.sell !== 0 ? fmt(p / v.sell * 100) + " %" : "—" } ] };
    },
    how: ["أدخل تكلفة شراء السلعة.", "أدخل سعر بيعها.", "إذا كان الناتج سالبًا فأنت في خسارة وليس ربح."],
    related: ["margin", "percentage", "discount"]
  },
  {
    slug: "margin", name: "حاسبة هامش الربح", icon: "📈",
    short: "احسب هامش الربح كنسبة من سعر البيع.",
    desc: "حاسبة هامش الربح: احسب هامش الربح كنسبة مئوية من سعر البيع بضغطة واحدة.",
    keywords: "هامش ربح margin نسبة",
    fields: [
      { key: "cost", label: "التكلفة", type: "number", placeholder: "مثال: 300" },
      { key: "sell", label: "سعر البيع", type: "number", placeholder: "مثال: 450" }
    ],
    compute(v) {
      if (v.sell === 0) return { main: { label: "", value: "" }, error: "سعر البيع لا يمكن أن يكون صفرًا." };
      return { main: { label: "هامش الربح", value: fmt((v.sell - v.cost) / v.sell * 100) + " %" }, subs: [{ label: "الربح", value: fmt(v.sell - v.cost) }] };
    },
    how: ["أدخل التكلفة وسعر البيع.", "هامش الربح = (سعر البيع − التكلفة) ÷ سعر البيع × 100.", "هامش 30% يعني أن 30% من سعر البيع هو ربحك."],
    related: ["profit", "percentage", "tax"]
  },
  {
    slug: "tax", name: "حاسبة الضريبة", icon: "🧾",
    short: "احسب قيمة الضريبة والمبلغ الإجمالي شامل الضريبة.",
    desc: "حاسبة الضريبة: أدخل المبلغ ونسبة الضريبة (مثلًا 15% ضريبة القيمة المضافة) لتحصل على قيمة الضريبة والإجمالي.",
    keywords: "ضريبة قيمة مضافة vat إجمالي",
    fields: [
      { key: "amount", label: "المبلغ قبل الضريبة", type: "number", placeholder: "مثال: 1000" },
      { key: "rate", label: "نسبة الضريبة %", type: "number", placeholder: "مثال: 15" }
    ],
    compute(v) {
      const t = v.amount * v.rate / 100;
      return { main: { label: "الإجمالي شامل الضريبة", value: fmt(v.amount + t) }, subs: [{ label: "قيمة الضريبة", value: fmt(t) }, { label: "المبلغ قبل الضريبة", value: fmt(v.amount) }] };
    },
    how: ["أدخل المبلغ قبل إضافة الضريبة.", "أدخل نسبة الضريبة (مثلًا 15%).", "ستظهر قيمة الضريبة والإجمالي النهائي."],
    related: ["discount", "bill-split", "percentage"]
  },
  {
    slug: "installment", name: "حاسبة القسط", icon: "🏦",
    short: "احسب القسط الشهري للتمويل أو القرض بالفائدة المركبة.",
    desc: "حاسبة القسط: احسب القسط الشهري للتمويل أو القرض بالفائدة المركبة، مع إجمالي الفوائد.",
    keywords: "قسط تمويل قرض بنك سيارة تقسيط",
    fields: [
      { key: "amount", label: "مبلغ التمويل", type: "number", placeholder: "مثال: 100000" },
      { key: "rate", label: "الفائدة السنوية %", type: "number", placeholder: "مثال: 5" },
      { key: "months", label: "عدد الأشهر", type: "number", placeholder: "مثال: 60" }
    ],
    compute(v) {
      if (v.months <= 0) return { main: { label: "", value: "" }, error: "عدد الأشهر يجب أن يكون أكبر من صفر." };
      const r = v.rate / 1200, n = v.months;
      const pmt = r > 0 ? v.amount * r / (1 - Math.pow(1 + r, -n)) : v.amount / n;
      const total = pmt * n;
      return { main: { label: "القسط الشهري", value: fmt(pmt) }, subs: [{ label: "إجمالي المبالغ المدفوعة", value: fmt(total) }, { label: "إجمالي الفوائد", value: fmt(total - v.amount) }] };
    },
    how: ["أدخل مبلغ التمويل.", "أدخل نسبة الفائدة السنوية وعدد الأشهر.", "تُستخدم طريقة القسط المركب الشائعة في البنوك."],
    related: ["savings", "bill-split", "tax"]
  },
  {
    slug: "savings", name: "حاسبة الادخار", icon: "🐢",
    short: "احسب مبلغ ادخارك بعد عدد من الأشهر مع العائد.",
    desc: "حاسبة الادخار: احسب رصيدك النهائي عند ادخار مبلغ شهري لعدد من الأشهر مع احتساب العائد.",
    keywords: "ادخار توفير مال فائدة بنك",
    fields: [
      { key: "monthly", label: "المبلغ الشهري", type: "number", placeholder: "مثال: 1000" },
      { key: "months", label: "عدد الأشهر", type: "number", placeholder: "مثال: 12" },
      { key: "rate", label: "العائد السنوي % (اختياري)", type: "number", placeholder: "0 إن لم يوجد", optional: true }
    ],
    compute(v) {
      if (v.months <= 0) return { main: { label: "", value: "" }, error: "عدد الأشهر يجب أن يكون أكبر من صفر." };
      const r = (v.rate || 0) / 1200, n = v.months;
      const fv = r > 0 ? v.monthly * (Math.pow(1 + r, n) - 1) / r : v.monthly * n;
      const dep = v.monthly * n;
      return { main: { label: "رصيدك النهائي", value: fmt(fv) }, subs: [{ label: "إجمالي ما أودعته", value: fmt(dep) }, { label: "الفوائد المكتسبة", value: fmt(fv - dep) }] };
    },
    how: ["أدخل المبلغ الشهري.", "حدد عدد الأشهر والعائد السنوي إن وجد.", "تُحتسب الفائدة شهريًا بطريقة الفائدة المركبة."],
    related: ["installment", "profit", "age"]
  },
  {
    slug: "age", name: "حاسبة العمر", icon: "🎂",
    short: "احسب عمرك بالسنوات والأشهر والأيام بدقة.",
    desc: "حاسبة العمر: احسب عمرك بالسنوات والأشهر والأيام بدقة، وبالأيام الكلية.",
    keywords: "عمر تاريخ ميلاد سنوات",
    fields: [{ key: "birth", label: "تاريخ الميلاد", type: "date" }],
    compute(v) {
      const b = new Date(v.birth), t = new Date();
      if (isNaN(b.getTime())) return { main: { label: "", value: "" }, error: "أدخل تاريخ ميلاد صحيحًا." };
      if (b > t) return { main: { label: "", value: "" }, error: "تاريخ الميلاد لا يمكن أن يكون في المستقبل." };
      let y = t.getFullYear() - b.getFullYear(), m = t.getMonth() - b.getMonth(), d = t.getDate() - b.getDate();
      if (d < 0) { m--; d += new Date(t.getFullYear(), t.getMonth(), 0).getDate(); }
      if (m < 0) { y--; m += 12; }
      const days = Math.floor((t.getTime() - b.getTime()) / 86400000);
      return { main: { label: "عمرك", value: `${y} سنة و ${m} شهر و ${d} يوم` }, subs: [{ label: "عمرك بالأيام", value: days.toLocaleString("en-US") }, { label: "عدد الأشهر", value: fmt(y * 12 + m) }] };
    },
    how: ["اختر تاريخ ميلادك من التقويم.", "اضغط «احسب» لعرض عمرك بدقة."],
    related: ["time-diff", "savings", "bill-split"]
  },
  {
    slug: "time-diff", name: "حاسبة فرق الوقت", icon: "⏱️",
    short: "احسب الفرق بين تاريخين أو وقتين بالأيام والساعات والدقائق.",
    desc: "حاسبة فرق الوقت: احسب المدة بين تاريخين أو وقتين بالأيام والساعات والدقائق.",
    keywords: "وقت فرق تاريخ مدة زمن",
    fields: [
      { key: "start", label: "الوقت / التاريخ الأول", type: "datetime-local" },
      { key: "end", label: "الوقت / التاريخ الثاني", type: "datetime-local" }
    ],
    compute(v) {
      const a = new Date(v.start), b = new Date(v.end);
      if (isNaN(a.getTime()) || isNaN(b.getTime())) return { main: { label: "", value: "" }, error: "أدخل التاريخين بشكل صحيح." };
      let diff = Math.abs(b.getTime() - a.getTime());
      const days = Math.floor(diff / 86400000); diff %= 86400000;
      const hours = Math.floor(diff / 3600000); diff %= 3600000;
      const mins = Math.floor(diff / 60000);
      const total = Math.abs(b.getTime() - a.getTime());
      return { main: { label: "الفرق بين الوقتين", value: `${days} يوم و ${hours} ساعة و ${mins} دقيقة` }, subs: [{ label: "إجمالي الساعات", value: fmt(total / 3600000) }, { label: "إجمالي الدقائق", value: fmt(total / 60000) }] };
    },
    how: ["أدخل التاريخ والوقت الأول.", "أدخل الثاني.", "ستظهر المدة بالأيام والساعات والدقائق."],
    related: ["age", "installment", "savings"]
  },
  {
    slug: "bill-split", name: "حاسبة تقسيم الفاتورة", icon: "🍽️",
    short: "قسّم فاتورة المطعم على مجموعة مع إضافة الإكرامية.",
    desc: "حاسبة تقسيم الفاتورة: قسّم فاتورة المطعم على مجموعة مع إضافة نسبة الإكرامية بسهولة.",
    keywords: "فاتورة مطعم تقسيم اكرامية بقشيش",
    fields: [
      { key: "total", label: "إجمالي الفاتورة", type: "number", placeholder: "مثال: 340" },
      { key: "tip", label: "نسبة الإكرامية % (اختياري)", type: "number", placeholder: "0", optional: true },
      { key: "people", label: "عدد الأشخاص", type: "number", placeholder: "مثال: 4" }
    ],
    compute(v) {
      if (v.people <= 0) return { main: { label: "", value: "" }, error: "عدد الأشخاص يجب أن يكون أكبر من صفر." };
      const tipA = v.total * (v.tip || 0) / 100, grand = v.total + tipA;
      return { main: { label: "نصيب كل شخص", value: fmt(grand / v.people) }, subs: [{ label: "قيمة الإكرامية", value: fmt(tipA) }, { label: "الإجمالي مع الإكرامية", value: fmt(grand) }] };
    },
    how: ["أدخل إجمالي الفاتورة.", "أضف نسبة الإكرامية إن أردت.", "حدد عدد الأشخاص."],
    related: ["tax", "discount", "percentage"]
  }
];

export const getCalc = (slug: string) => CALCULATORS.find((c) => c.slug === slug);
